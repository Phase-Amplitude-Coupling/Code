﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

public class WritePositionVelocity : MonoBehaviour {
	public Rigidbody rb;
	public string File_name;
	private StreamWriter writer1;
	private StreamWriter writer2;
	private string vel;
	private string pos;
	public GameObject BaseLogic; 
	public int CurrentIteration;
	public int PastIteration;
	void Start () {
		File_name = this.transform.name;
		rb = this.GetComponent<Rigidbody> ();
		CurrentIteration = 0;
		PastIteration = 0;
		writer1 = new StreamWriter(string.Concat("./",File_name + CurrentIteration.ToString()), false);


	}
	

	void LateUpdate () {
		CurrentIteration = BaseLogic.GetComponent<GameControl> ().Iteration;
		if (PastIteration != CurrentIteration) {
			PastIteration = CurrentIteration;
			writer1.Close ();
			writer1 = new StreamWriter(string.Concat("./",File_name + CurrentIteration.ToString()), false);
		
		}
		

		string velx = rb.velocity.x.ToString();
		string vely = rb.velocity.y.ToString();
		string velz = rb.velocity.z.ToString();
		string posx = transform.position.x.ToString();
		string posy = transform.position.y.ToString();
		string posz = transform.position.z.ToString();
		string tempString = string.Concat (velx, " ");
		string tempString2 = string.Concat (tempString," ");
		string tempString3 = string.Concat (tempString2, vely);
		string tempString4 = string.Concat (tempString3," ");
		string tempString5 = string.Concat (tempString4, velz);
		string tempString6 = string.Concat (tempString5," ");
		string tempString7 = string.Concat (tempString6, posx);
		string tempString8 = string.Concat (tempString7," ");
		string tempString9 = string.Concat (tempString8, posy);
		string tempString10 = string.Concat (tempString9," ");
		string tempString11 = string.Concat (tempString10,posz);
		if (BaseLogic.GetComponent<GameControl> ().Running) {
			writer1.WriteLine (tempString11);
		}

	//	void LateUpdate(){


	}
}
