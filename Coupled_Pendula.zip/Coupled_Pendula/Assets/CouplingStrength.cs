﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CouplingStrength : MonoBehaviour {
	public float couplingStrength;
	public bool ChangeCoupling;
	public float CouplingConstant;
	public SpringJoint sj;
	public Slider CouplingSlider;


	void Start(){
		CouplingSlider = this.GetComponent<Slider> ();

		CouplingConstant=1;
		ChangeCoupling = true;
	}

void FixedUpdate(){
	if (ChangeCoupling) {
			sj.spring = couplingStrength * CouplingConstant;
			ChangeCoupling  = false;
	}

}
public void StringStrength(float Amount){
		couplingStrength = Amount;
		ChangeCoupling = true;
}
}
