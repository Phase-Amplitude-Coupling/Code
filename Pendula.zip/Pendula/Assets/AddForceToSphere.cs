﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddForceToSphere : MonoBehaviour {

	public float ImpulseAmount;
	public bool DoPush;
	public Rigidbody rb;
	public Slider SliderControl;
	public float PushScale;
	public int TimeFromReset;
	public int MaxT;

	public bool DoRestart;
	public float InputDuration;
	// Use this for initialization
	void Start () {
		InputDuration = 2;
		rb = GetComponent<Rigidbody>();
		MaxT = Mathf.RoundToInt(InputDuration/Time.deltaTime);
		Debug.Log (MaxT);
		DoRestart = false;
		DoPush = false;
		PushScale = 1;

	}
	
	// Update is called once per frame


	void FixedUpdate(){
		
			if (DoRestart == true) {

				TimeFromReset = 0;	
				DoRestart = false;
				DoPush = true;
			}
			//SliderControl.value = 0f;
		if (DoPush) {

		if (TimeFromReset == MaxT && DoPush) {
			
			DoPush = false;
		}

		if (TimeFromReset < MaxT && DoPush) {
			TimeFromReset =TimeFromReset+ 1;
			
			 

			//
			var TempInputAmount = ImpulseAmount*Mathf.Exp(-1*Mathf.Pow(TimeFromReset - MaxT/2,2)/Mathf.Pow(MaxT/8,2));

			//Debug.Log (TempInputAmount);
			this.GetComponent<Rigidbody> ().AddForce (TempInputAmount, TempInputAmount, TempInputAmount,	ForceMode.Force);

		}
	}
	}
	public void PushBall(float Amount){
		ImpulseAmount = Amount*PushScale;

		DoRestart = true;
	}

	public void InputDurationInput(string Amount4){
		InputDuration = float.Parse(Amount4);
		MaxT = Mathf.RoundToInt(InputDuration/Time.deltaTime);
	}
}
