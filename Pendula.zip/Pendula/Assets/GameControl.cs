﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameControl : MonoBehaviour {
	//public int TimePoint=0;
	public GameObject P1S;
	public GameObject P2S;
	public GameObject P3S;
	public GameObject P1;
	public GameObject P2;
	public GameObject P3;
	public GameObject CouplingSlider1;
	public GameObject CouplingSlider2;
	public GameObject CouplingSlider3;
	private float CouplingAmount;
	private float RandPushValue1;
	private Vector3 P1StartPos;
	private Vector3 P2StartPos;
	private Vector3 P3StartPos;
	private Vector3 P1SStartPos;
	private Vector3 P2SStartPos;
	private Vector3 P3SStartPos;
	public int Iteration;
	//private  P1StartPos;

	private Quaternion P1StartRot;
	private Quaternion P2StartRot;
	private Quaternion P3StartRot;
	private Quaternion P1SStartRot;
	private Quaternion P2SStartRot;
	private Quaternion P3SStartRot;
	public bool Running;
	public float NumTimepoints;
	public float CouplingIncrements;
	//public float StartingCoupling;
	public float StartingPush;
	public float TimeStart;

	// Use this for initialization
	void Start () {
		NumTimepoints = 10000;
		StartingPush = 20.0f;
		CouplingIncrements = 0.0f;
		Running = false;
		TimeStart = Time.time;
		Iteration = 0;
		//StartingCoupling = 0;
		CouplingAmount = 0;
		//RandPushValue1 = Random.Range (5.0f, 20.0f);



	}

	// Update is called once per frame
	void Update () {
		if (Running == true) {
			//TimePoint++;
			//if ((TimePoint % NumTimepoints) == 0) {
			if ((Time.time - TimeStart) > NumTimepoints) {
				TimeStart = Time.time;
				CouplingAmount = CouplingAmount + CouplingIncrements;
				Iteration++;
			}
			if ((Time.time-TimeStart)<0.001f){
				
				P1S.GetComponent<Rigidbody> ().isKinematic = true;
				P2S.GetComponent<Rigidbody> ().isKinematic = true;
				P3S.GetComponent<Rigidbody> ().isKinematic = true;
				P1.GetComponent<Rigidbody> ().isKinematic = true;
				P2.GetComponent<Rigidbody> ().isKinematic = true;
				P3.GetComponent<Rigidbody> ().isKinematic = true;


				P1S.transform.position = P1SStartPos;
				P2S.transform.position = P2SStartPos;
				P3S.transform.position = P3SStartPos;
				P1.transform.position = P1StartPos;
				P2.transform.position = P2StartPos;
				P3.transform.position = P3StartPos;

				P1S.transform.rotation = P1SStartRot;
				P2S.transform.rotation = P2SStartRot;
				P3S.transform.rotation = P3SStartRot;
				P1.transform.rotation = P1StartRot;
				P2.transform.rotation = P2StartRot;
				P3.transform.rotation = P3StartRot;



				CouplingSlider1.GetComponent<CouplingStrength> ().StringStrength (CouplingAmount);
				CouplingSlider2.GetComponent<CouplingStrength> ().StringStrength (CouplingAmount);
				CouplingSlider3.GetComponent<CouplingStrength> ().StringStrength (CouplingAmount);
			      
			}	

	
		}
			

	}

	void LateUpdate(){
		
//		if ((TimePoint % 2500) == 0) { 
//			RandPushValue1 = 0;
//			P1S.GetComponent<AddForceToSphere> ().PushBall (RandPushValue1);
//		}
		if (Running == true) {
			if ((Time.time-TimeStart)<0.001f) { 
				
				//P1S.GetComponent<AddForceToSphere> ().PushBall(StartingPush);
				//RandPushValue1 = Random.Range (5.0f, 20.0f);
				P1S.GetComponent<Rigidbody> ().isKinematic = false;
				P2S.GetComponent<Rigidbody> ().isKinematic = false;
				P3S.GetComponent<Rigidbody> ().isKinematic = false;
				P1.GetComponent<Rigidbody> ().isKinematic = false;
				P2.GetComponent<Rigidbody> ().isKinematic = false;
				P3.GetComponent<Rigidbody> ().isKinematic = false;
				P1S.GetComponent<AddForceToSphere> ().PushBall (StartingPush);
			}

		}
	}

	public void SpringCouplingIncrements(string Amount1){
		if (Running == false) {
			CouplingIncrements = float.Parse (Amount1);
		}
	}
		

	public void NumIterationsIncrements(string Amount2){
		NumTimepoints = float.Parse(Amount2);
	}



	public void PushValue(string Amount3){

			StartingPush = float.Parse (Amount3);

	}


	public void SpringCouplingStart(string Amount4){
		if (Running == false) {
			CouplingAmount = float.Parse (Amount4);

		}
	}


	public void StartPress(){
		Running = true;
		TimeStart = Time.time;
		P1S.GetComponent<Rigidbody> ().isKinematic = true;
		P2S.GetComponent<Rigidbody> ().isKinematic = true;
		P3S.GetComponent<Rigidbody> ().isKinematic = true;
		P1.GetComponent<Rigidbody> ().isKinematic = true;
		P2.GetComponent<Rigidbody> ().isKinematic = true;
		P3.GetComponent<Rigidbody> ().isKinematic = true;
		P1StartPos = P1.transform.position;
		P2StartPos = P2.transform.position;
		P1SStartPos = P1S.transform.position;
		P2SStartPos = P2S.transform.position;
		P3StartPos = P3.transform.position;
		P3SStartPos = P3S.transform.position;

		P1StartRot = P1.transform.rotation;
		P2StartRot = P2.transform.rotation;
		P1SStartRot = P1S.transform.rotation;
		P2SStartRot = P2S.transform.rotation;
		P3StartRot = P3.transform.rotation;
		P3SStartRot = P3S.transform.rotation;


		P1S.GetComponent<AddForceToSphere> ().PushBall(StartingPush);
		//CouplingAmount = 0.00000f;
	}
}
